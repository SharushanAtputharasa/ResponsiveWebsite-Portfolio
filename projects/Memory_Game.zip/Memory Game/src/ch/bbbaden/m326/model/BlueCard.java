/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.m326.model;

/**
 *
 * @author sharu
 */
public class BlueCard extends Card {

    public BlueCard() {
        color = "-fx-background-color:#0000FF";
    }

}

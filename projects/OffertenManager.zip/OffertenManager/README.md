# OffertenManger
